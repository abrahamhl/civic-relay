# SENDA — Sistema de Enrutamiento de Emergencia por canales alternativos

*(antes Civic Relay / OEP)* · **Si existe un camino hasta tu gente, SENDA lo encuentra.**

**Objetivo de diseño** (sin medir aún en campo): que un mensaje llegue cuando la red cae. Para ello SENDA combinaría vecinos con la app (Bluetooth, Wi-Fi Direct), quien tenga Internet por satélite u otro operador, SMS, satélite directo al móvil y pasarelas, y elegiría en cada momento la ruta más rápida. El satélite directo al móvil solo cuenta donde exista: en España no consta lanzamiento comercial de Starlink directo al móvil, y Skylo da SOS y texto en móviles compatibles ([fuentes](docs/research/PLATAFORMAS_AVIACION_SATELITE_2026-11-14.md)). **Probado hoy en navegador:** mensaje cifrado de ≤ 160 caracteres, paso por sonido entre dos móviles y llamada por red local. Bluetooth y Wi-Fi Direct están modelados en el núcleo, pero no validados en dispositivos. Cuando una autoridad declara una zona de emergencia (o la red de teléfonos detecta un sismo corroborado), los teléfonos con SENDA pasan a **modo relé preautorizado**. El núcleo incluye modelos y simulaciones (declaradas como tales) de coordinación de familias e instituciones, de puente para personas atrapadas bajo escombros y de localización con Wi-Fi CSI. No hay validación física.

### 🏔️ Sobrevuelo con datos reales · Langtang, Nepal (`/senda/vuelo`)

![Sobrevuelo 3D del colapso de Langtang con relieve Copernicus y Sentinel-2](docs/media/consola/vuelo-nepal.png)

El sobrevuelo combina datos reales:
- la señal sísmica del colapso catalogada por USGS ([us7000tbwb](https://earthquake.usgs.gov/earthquakes/eventpage/us7000tbwb), M 5,2, tipo «landslide», 26-08-2026 02:52 UTC);
- imágenes Sentinel-2 de antes (12-08) y de después (26-10);
- el relieve Copernicus DEM GLO-30.

Se suman dos elementos calculados por SENDA: un cambio detectado por NDVI, que **no es un mapa oficial de daños**, y una ruta de 44,6 km que sigue ese cambio. Detalles y límites en [docs/research/NEPAL_LANGTANG_2026-08-26.md](docs/research/NEPAL_LANGTANG_2026-08-26.md). Vídeo: [`SENDA-nepal-sobrevuelo.mp4`](investor-next/public/media/senda-demo/SENDA-nepal-sobrevuelo.mp4).

### 🌍 Consola de situación (`/senda/consola`)

![SENDA Consola: situación fusionada con evidencia de varias fuentes](docs/media/consola/c-sel.png)

| Calor | Columnas 3D | Plano | Muro de vídeo |
|---|---|---|---|
| ![calor](docs/media/consola/c-calor.png) | ![columnas](docs/media/consola/c-columnas.png) | ![plano](docs/media/consola/c-plano.png) | ![muro](docs/media/consola/c-muro.png) |

En la consola se ven 16.699 elementos reales y fechados, con su fuente y licencia: GDACS, DGT, NDW, ADS-B (adsb.lol), NOAA GOES-16, TfL y Caltrans. El motor `fusion.mjs` los cruza y forma situaciones: cada una tiene un ancla y la evidencia de las demás capas, con su procedencia. Lo simulado lleva la etiqueta SIMULACIÓN. Son fotos de datos, no tiempo real. Vídeo de la consola: [`SENDA-consola-promo.mp4`](investor-next/public/media/senda-demo/SENDA-consola-promo.mp4) (89 s, grabado de la app real).

- **Empieza aquí:** [`entrega/LEEME_PRIMERO.md`](entrega/LEEME_PRIMERO.md) (carpeta autocontenida: web para Hostinger, zips y guía) · traspaso para otra IA: [docs/handoff/HANDOFF_COMPLETO_2026-11-05.md](docs/handoff/HANDOFF_COMPLETO_2026-11-05.md) · financiación: [docs/financiacion/RONDA_FINANCIACION_2026-11-05.md](docs/financiacion/RONDA_FINANCIACION_2026-11-05.md) · paper: [docs/paper/SENDA_FUEGO3D_paper.md](docs/paper/SENDA_FUEGO3D_paper.md) · v0.20, incendios de referencia y coches + cámaras + fuego: [docs/research/REFERENCIAS_COCHES_CAMARAS_2026-11-06.md](docs/research/REFERENCIAS_COCHES_CAMARAS_2026-11-06.md)
- **Visión vigente:** [docs/product/SENDA_VISION_2026-11-04.md](docs/product/SENDA_VISION_2026-11-04.md)
- **Núcleo:** [`packages/senda`](packages/senda) — `pnpm --filter @senda/core test` · `pnpm --filter @senda/core evidence`
- **Evidencia de escenarios:** [`evidence/senda/scenarios.json`](evidence/senda/scenarios.json)

---

# OEP / Civic Relay — Offline Emergency Protocol

**Plataforma europea modular de anticipación de riesgos, continuidad de comunicaciones y coordinación de personas, equipos e infraestructuras.** Civic Relay persigue esta visión mediante OEP, adaptadores autorizados y una cadena de evidencia que distingue observación, predicción, custodia y confirmación. El software actual es un laboratorio de investigación; el programa completo requiere validación física y socios.

**Visión canónica:** [maestro CR-VM-2026-10-25](docs/product/CIVIC_RELAY_VISION_MAESTRA_2026-10-25.md) · [integración, arquitectura, pruebas y límites](docs/product/MASTER_VISION_INTEGRATION.md). El maestro conserva los 20 módulos y ocho escenarios; no acredita capacidades operativas. Prevalece sobre formulaciones anteriores del alcance.

🌐 **[Abrir la web avanzada de OEP — demostración interactiva ES / EN / NL](https://civic-relay-investor.vercel.app)**  
🧪 **[Código oficial integrado en master](https://github.com/abrahamhl/civic-relay/tree/master/investor-next)**  
📋 **[Expediente técnico y estado real](https://github.com/abrahamhl/civic-relay/blob/master/docs/audits/LATEST_ENGINEERING_STATUS.md)**

> **ÚNICO DOMINIO OFICIAL:** https://civic-relay-investor.vercel.app. Todas las páginas públicas y propuestas deben utilizar esta URL con rutas `/`, `/es/` y `/nl/`. El historial de la demo V0.1 existe como código, pero no representa el producto actual. El núcleo de investigación y las correcciones web están en `master`; nuevas mitigaciones de seguridad se revisan por PR antes de fusionar. La producción puede ir por detrás del último commit; las comunicaciones Android↔Android no están validadas físicamente y no existe integración operativa con 112, satélites o radar trans-pared. No usar en emergencias reales.

> **Fuente verificable:** [estado del CTO](docs/audits/LATEST_ENGINEERING_STATUS.md), [registro de evidencias](docs/investor/EVIDENCE_REGISTER.md) y [PR #8 (fiabilidad experimental)](https://github.com/abrahamhl/civic-relay/pull/8). Verificar SHA y CI exactos antes de enviar un dossier.

---

### 🌊📡💧 Tres motores sobre datos reales (17-11-2026)

Los tres se calculan en el navegador y cada cifra sale de ejecutar el código del repositorio sobre los ficheros de `investor-next/public/senda/data/`.

| Motor | Qué responde | Datos | Naturaleza del resultado |
|---|---|---|---|
| **Aislamiento por inundación** (`/senda/aislamiento`) | Qué cruces secos se quedan sin camino a un hospital, centro de salud, bomberos o policía | Agua observada por Copernicus EMS (EMSR773, 30 y 31-10-2024) y calles de OpenStreetMap | Cálculo sobre datos observados; la regla de corte es un escenario declarado |
| **Planificador de radio** (`/senda/radio`) | Dónde poner repetidores de baja potencia si cae la red móvil | Copernicus DEM GLO-30 de la cuenca del Poyo | **Modelo** (espacio libre + ITU-R P.526); no es una medida de campo |
| **Agua en Países Bajos** (`/senda/agua-nl`) | Qué estaciones suben y cuánto tarda la onda de una a otra | 25 estaciones de Rijkswaterstaat: 28 días de medidas y previsión oficial | Medido; las reglas de atención son de SENDA, no alarmas oficiales |

![Aislamiento por inundación en l'Horta Sud](docs/media/nuevos/aislamiento-horta-sud.png)

Límites: el satélite no delimitó agua dentro de los cascos urbanos densos, así que el aislamiento se queda corto ahí; el plan de radio es terreno desnudo y necesita medida de campo; el agua es una foto fija del 17-11-2026 sin umbrales oficiales. Detalle y fuentes en `docs/propuesta/PROPUESTA_GOBIERNOS_ES_NL_2026-11.md` y `docs/financiacion/RUTAS_FINANCIACION_ES_NL_UE_2026-11.md`.

## Transparencia del uso de inteligencia artificial

Civic Relay incluye desarrollo, documentación y pruebas asistidos por IA generativa (entre otras herramientas, ChatGPT y asistentes de programación). Los cambios generados requieren revisión humana, validación automatizada y atribución transparente; los tests green no reemplazan una auditoría independiente. No se presenta código generado como trabajo puramente humano.

**Restricción NLnet:** desde el 20-10-2026, [la política v2.0](https://nlnet.nl/foundation/policies/generativeAI/2.0/) prohíbe redacción, edición y traducción de solicitudes mediante IA generativa (salvo la excepción de accesibilidad declarada) y producir artefactos financiados con GenAI. Por tanto, este repositorio y estos documentos no autorizan una candidatura automatizada a NLnet. Antes de presentarse debe verificarse y declarar el uso previo de IA y establecer un plan de trabajo que cumpla estrictamente las condiciones.

## Archivo de la demo histórica V0.1

## Historical Civic Relay V0.1 demo

Demo ficticia de comunicación en crisis, offline-first y de transporte múltiple, diseñada como ejercicio de ingeniería para entornos de conectividad degradada.

> ⚠️ No es un servicio de emergencias. No hay aval institucional, conformidad ENS ni prestación operativa. Todo el transporte es **simulado en la misma página** y la cola es **en memoria** (se pierde al recargar). No introduzcas datos personales ni emergencias reales.

🌐 **Única web pública recomendada:** https://civic-relay-investor.vercel.app
- **Demostración histórica V0.1:** código conservado en [`apps/web/`](apps/web/) para revisión técnica; no distribuir antiguas URLs como webs oficiales.

## Qué demuestra

- **Transporte múltiple** – un mensaje puede propagarse por varias rutas simuladas.
- **Almacenar y reenviar** – si no hay rutas, el mensaje queda en cola (`QUEUED`) hasta que aparezcan.
- **Canalización** – `MESSAGE → STORE → ROUTE → MULTIPATH → DEDUP → ACK`.
- **Deduplicación real** – el mismo sobre entregado por dos rutas produce **un** mensaje lógico que retiene ambas rutas.
- **Límites honestos** – separa explícitamente lo simulado de lo no probado.

## Ejecutar

### Desarrollo local
```bash
pnpm install --frozen-lockfile
pnpm dev          # Desarrollo en http://localhost:3000
pnpm build        # Build producción
pnpm test         # Tests
pnpm lint         # Type-check
```

### Deploy a Vercel (Producción)
```bash
# Opción 1: CLI (rápido)
npm install -g vercel
vercel            # Deploy preview
vercel --prod     # Deploy producción

# Opción 2: Script automatizado (recomendado)
.\scripts\deploy.ps1           # Windows
./scripts/deploy.sh preview    # Linux/Mac
```


Servir la demo estática desde `apps/web/dist`. La API y el servicio reales **no** se exponen en esta demo.

## Pruebas

`packages/core/tests/*.test.mjs` (runner nativo de Node) cubre:

- escenario dorado offline → mesh → later IP → receptor único → 2 rutas;
- recepción **sin** acknowledgment del receptor → nunca `DELIVERED`;
- TTL caducado rechazado antes de rutar;
- `verificationState=OFFICIAL` forjado, sobre malformado y colisión de ID rechazados;
- mismo mensaje por dos rutas → un mensaje con ambas rutas;
- una ruta que falla no bloquea una ruta sana.

## Límites conocidos

- La cola, el historial y la deduplicación son **de sesión** (memoria).
- No hay cifrado extremo a extremo en el flujo de la demo; las primitivas criptográficas existen pero son experimentales y no están conectadas al despacho.
- No se registra ningún service worker ni PWA; el manifiesto es mínimo.
- No hay backend productivo, autenticación, autorización ni sistema de emergencias.

## Documentación

### Producto, Arquitectura 3D Mission Control y Sector Intelligence (2026-10-22)
- [`docs/product/VOICE_VISION_REQUIREMENTS_2026-10-22.md`](docs/product/VOICE_VISION_REQUIREMENTS_2026-10-22.md) – transcripción íntegra con marcas temporales (`00:00`–`06:33.59`) de la visión original del fundador, matriz funcional (`V01..V13`, `W01..W03`) y contraste con el código
- [`docs/product/WEBSITE_INFORMATION_ARCHITECTURE.md`](docs/product/WEBSITE_INFORMATION_ARCHITECTURE.md) – tesis de comprensión en 30 segundos, relación `Civic Relay` / `OEP`, arquitectura de 3 superficies (`Descubrir`, `Explorar / Mission Control`, `Investigar / Science`), recorrido causal de 8 escenas y rutas estáticas (`EN`, `ES`, `NL`)
- [`docs/product/INTERACTION_SPEC_AND_STATE_MODEL.md`](docs/product/INTERACTION_SPEC_AND_STATE_MODEL.md) – especificación de interacción 3D (`THREE.Raycaster`, órbitas Tierra/Luna/Marte, máscara continental Natural Earth 1:110m, fallback SVG 2D) y acoplamiento determinista con `runScenario()` y `createStoreForwardEngine()`
- [`docs/product/CAMERA_SECTOR_ARCHITECTURE.md`](docs/product/CAMERA_SECTOR_ARCHITECTURE.md) – arquitectura de **Sector Intelligence & CCTV Coordination** (`El Tiemblo · Ávila`, `Valencia · Turia`, `Arnhem · NL`), catálogo abierto DGT/Rijkswaterstaat vs. telemetría sintética, validación anti-SSRF, RBAC fail-closed, mosaico de privacidad y conos FOV 2.5D no calibrados
- [`docs/product/SCIENTIFIC_TRUTH_MATRIX.md`](docs/product/SCIENTIFIC_TRUTH_MATRIX.md) – matriz de verdad científica (`IMPLEMENTADO`, `SIMULADO`, `EN INVESTIGACIÓN`, `SIN PERMISOS`, `NO FACTIBLE CON WEB ACTUAL`)
- [`docs/product/BEFORE_AFTER_UX_AUDIT.md`](docs/product/BEFORE_AFTER_UX_AUDIT.md) – auditoría antes/después desde 6 perspectivas, 10 deficiencias corregidas y evidencia automatizada en Chromium (`P01..P10`)

### Técnica e Inversión (Dossier 2026)
- [`docs/investor/EXECUTIVE_SUMMARY.md`](docs/investor/EXECUTIVE_SUMMARY.md) – resumen ejecutivo y posicionamiento técnico (TRL 3–4)
- [`docs/investor/ONE_PAGE_PITCH.md`](docs/investor/ONE_PAGE_PITCH.md) – pitch de una página para inversores e instituciones
- [`docs/investor/TECHNICAL_DUE_DILIGENCE.md`](docs/investor/TECHNICAL_DUE_DILIGENCE.md) – guía de due diligence técnica y comandos reproducibles
- [`docs/investor/ARCHITECTURE.md`](docs/investor/ARCHITECTURE.md) – flujo de 8 etapas (`EMERGENCY EVENT → ZONE → HUMAN STATUS → CONSENT → MESSAGE → NETWORK PATH → ACK → EVIDENCE`)
- [`docs/investor/EVIDENCE_REGISTER.md`](docs/investor/EVIDENCE_REGISTER.md) – registro maestro de afirmaciones y niveles de evidencia
- [`docs/investor/DIFFERENTIATION.md`](docs/investor/DIFFERENTIATION.md) – diferenciación frente a SOS satelital, mensajería mesh y alertas broadcast
- [`docs/investor/RISKS_AND_MITIGATIONS.md`](docs/investor/RISKS_AND_MITIGATIONS.md) – matriz de riesgos técnicos, operativos y regulatorios
- [`docs/investor/TRL_AND_VALIDATION_ROADMAP.md`](docs/investor/TRL_AND_VALIDATION_ROADMAP.md) – evaluación TRL y hoja de ruta M0–M4
- [`docs/investor/PILOT_PROPOSAL.md`](docs/investor/PILOT_PROPOSAL.md) – propuesta de piloto controlado de 12 semanas
- [`docs/investor/FUNDING_OPPORTUNITIES.md`](docs/investor/FUNDING_OPPORTUNITIES.md) – convocatorias verificadas UE / Países Bajos (Horizon Europe Cluster 3, NLnet/NGI, RVO WBSO/MIT)
- [`docs/investor/FINANCIAL_SCENARIOS.md`](docs/investor/FINANCIAL_SCENARIOS.md) – escenarios financieros **ilustrativos**, no previsiones (€50k / €180k / €400k)
- [`docs/security/THREAT_MODEL.md`](docs/security/THREAT_MODEL.md) – modelo de amenazas y controles implementados
- [`docs/security/DEPENDENCY_AND_LICENSE_AUDIT.md`](docs/security/DEPENDENCY_AND_LICENSE_AUDIT.md) – auditoría de dependencias y licencias (MIT)
- [`docs/security/DATA_AND_CONSENT_BOUNDARIES.md`](docs/security/DATA_AND_CONSENT_BOUNDARIES.md) – privacidad, consentimiento opt-in y purga local
- [`docs/audits/SIX_ORACLE_INDEPENDENT_REVIEWS_2026.md`](docs/audits/SIX_ORACLE_INDEPENDENT_REVIEWS_2026.md) – revisión en 6 perspectivas de ingeniería **hecha por asistentes de IA en distintos roles**: no es una auditoría independiente humana
- [`docs/audits/INVESTOR_READINESS_STATUS.md`](docs/audits/INVESTOR_READINESS_STATUS.md) – estado integral de preparación e invariantes verificados
- [`docs/audits/HUMAN_ACTION_REQUIRED.md`](docs/audits/HUMAN_ACTION_REQUIRED.md) – protocolo físico pendiente con 2 teléfonos Android (`PHYSICAL_TEST_PENDING`)
- [`docs/AUDITORIAS_INVERSION_PUBLICA.md`](docs/AUDITORIAS_INVERSION_PUBLICA.md) – cinco auditorías técnicas y delegaciones de responsabilidad
- [`docs/RELEASE_TRUTH_V0_1.md`](docs/RELEASE_TRUTH_V0_1.md) – verificación ejecutada (instalación/build/test/lint) vs. afirmaciones
- [`docs/ASTRA_RED_TEAM.md`](docs/ASTRA_RED_TEAM.md) – revisión adversarial de liberación
- [`docs/CRYPTO_ARCHITECTURE.md`](docs/CRYPTO_ARCHITECTURE.md) – criptografía experimental
- [`docs/WORKWIZE_CASE_STUDY.md`](docs/WORKWIZE_CASE_STUDY.md) – caso para entrevista

## Autor

Abraham Haddioui · AI-native product engineer · proyecto asistido por IA.

## Licencia

MIT.

Este repositorio es una **demo ficticia** para evaluación y aprendizaje. No está pensado para uso en emergencias reales ni para su adquisición operativa en su estado actual.
