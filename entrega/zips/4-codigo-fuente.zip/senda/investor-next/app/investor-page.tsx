import MissionControl from './mission-control';
import ScrollExperience from './scroll-experience';
import CrisisStory from './crisis-story';
import CoordinationLab from './coordination-lab';
import EvidenceBoard from './evidence-board';
import TelecomAndRfRadarSuite from './telecom-rf-radar-suite';
import LiveHardwareAndDealRoomConsole from './live-hardware-console';
import SectorIntelligenceConsole from './sector-intelligence-console';
import {HyperFramesCinemaDeck} from './hyperframes-cinema-deck';
import {AppleLivingNav} from './apple-living-nav';
import {WhatItDoes,SystemExplained,DeveloperBlueprint} from './system-explained';
import {routingPitch} from './routing-pitch';
import {getCopy,type Locale} from './copy';
import ResponsiveHeader from './responsive-header';
import SendaHome from './senda-home';
import AudienceFilter from './audience-filter';
import LanguageDocument from './language-document';
import MasterVision from './master-vision';

const source='https://github.com/abrahamhl/civic-relay';

const funding='https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/HORIZON-CL3-2026-01-SSRI-04';
const dossier=source+'/blob/master/docs/README.md';
const contact=source+'/issues/new?template=pilot-or-grant-partner.yml';
const chapterNavigation:Record<Locale,Array<{href:string;label:string}>>={
 en:[{href:'#what-oep-does',label:'WHAT IT DOES'},{href:'#architecture',label:'THE 3D STORY'},{href:'#how-it-works',label:'HOW IT WORKS'},{href:'#routing-lab',label:'TRY THE LAB'},{href:'#developer-stack',label:'TECH STACK'},{href:'#evidence',label:'EVIDENCE'}],
 es:[{href:'#what-oep-does',label:'QUÉ HACE'},{href:'#architecture',label:'HISTORIA 3D'},{href:'#how-it-works',label:'CÓMO FUNCIONA'},{href:'#routing-lab',label:'PROBAR LAB'},{href:'#developer-stack',label:'TECNOLOGÍA'},{href:'#evidence',label:'EVIDENCIAS'}],
 nl:[{href:'#what-oep-does',label:'WAT HET DOET'},{href:'#architecture',label:'3D-VERHAAL'},{href:'#how-it-works',label:'WERKING'},{href:'#routing-lab',label:'LAB PROBEREN'},{href:'#developer-stack',label:'TECHNIEK'},{href:'#evidence',label:'BEWIJS'}]
};

const thirtySecondThesis:Record<Locale,{
 brandTag:string;
 title:string;
 subtitle:string;
 exactQuote:string;
 ctaSimulate:string;
 ctaExploreMap:string;
 ctaEvidence:string;
 surfacesTitle:string;
 surfaces:Array<{id:string;tag:string;name:string;desc:string;targetAnchor:string;routeHref:string}>;
 eightScenes:Array<{num:string;tag:string;summary:string;targetAnchor:string;badge:string}>;
}>={
 es:{
  brandTag:'CIVIC RELAY (PLATAFORMA) · OEP — OFFLINE EMERGENCY PROTOCOL (PROTOCOLO DE INVESTIGACIÓN)',
  title:'Cuando cae la red, la coordinación no debería desaparecer.',
  subtitle:'Civic Relay es un programa tecnológico europeo de anticipación de riesgos, continuidad de comunicaciones y coordinación de personas, equipos e infraestructuras. Une información con procedencia, mensajes conservados, rutas terrestres o satelitales autorizadas y confirmaciones verificables. Hoy se demuestra software y simulación; la validación física y las integraciones institucionales siguen pendientes.',
  exactQuote:'«Civic Relay investiga cómo coordinar avisos, estados voluntarios de personas y rutas alternativas entre dispositivos y redes compatibles cuando falla parte de la conectividad. El prototipo permite experimentar con zonas de emergencia, permisos, mensajes, almacenamiento y reenvío y confirmaciones en un escenario simulado. La comunicación real entre teléfonos y con servicios oficiales todavía requiere validación e integración autorizada».',
  ctaSimulate:'Simular una emergencia',
  ctaExploreMap:'Explorar el mapa interactivo',
  ctaEvidence:'Ver qué funciona de verdad',
  surfacesTitle:'TRES SUPERFICIES COMPLEMENTARIAS (DIVULGACIÓN PROGRESIVA)',
  surfaces:[
   {id:'surface-discover',tag:'A · DESCUBRIR',name:'Historia y Resumen en 30s',desc:'Qué problema resuelve, para quién y con qué límites honestos, sin necesidad de jerga 3GPP/CSI/CAP.',targetAnchor:'#what-oep-does',routeHref:'/es/'},
   {id:'surface-explore',tag:'B · EXPLORAR / MISSION CONTROL',name:'Globo 3D + Sector Intelligence CCTV',desc:'Globo 3D con selección raycast, sectores (El Tiemblo, Valencia, Arnhem), conos FOV estimados y cámaras públicas/demo.',targetAnchor:'#sector-intelligence',routeHref:'/es/mission-control/'},
   {id:'surface-science',tag:'C · INVESTIGAR / SCIENCE & LAB',name:'Motor Determinista, Criptografía y Evidencia',desc:'Cola Store-and-Forward, firmas reales WebCrypto ECDSA P-256, laboratorio Android Nearby y matriz científica.',targetAnchor:'#routing-lab',routeHref:'/es/science/'}
  ],
  eightScenes:[
   {num:'01',tag:'DESASTRE',summary:'Incendio o apagón inutiliza una antena; la cobertura del sector cambia.',targetAnchor:'#story',badge:'SYNTHETIC SIMULATION'},
   {num:'02',tag:'PERSONAS',summary:'Nodos voluntarios declaran SAFE o SOS; UNKNOWN significa sin respuesta, nunca herido.',targetAnchor:'#routing-lab',badge:'REAL CODE / LOCAL LAB'},
   {num:'03',tag:'CONSENTIMIENTO',summary:'Permisos granulares opt-in; ningún sensor ajeno se activa sin permiso del usuario y SO.',targetAnchor:'#routing-lab',badge:'REAL CODE / LOCAL LAB'},
   {num:'04',tag:'RUTAS',summary:'«Policía de tráfico» alterna BLE/Wi-Fi/Gateway virtual según batería, prioridad y TTL.',targetAnchor:'#how-it-works',badge:'REAL CODE / LOCAL LAB'},
   {num:'05',tag:'SECTORES Y CÁMARAS',summary:'Del globo al sector (El Tiemblo/Valencia/Arnhem) con cámaras públicas DGT/RWS y conos estimados.',targetAnchor:'#sector-intelligence',badge:'LIVE THIRD-PARTY DATA — SOURCE/TIMESTAMP'},
   {num:'06',tag:'COORDINACIÓN Y ACK',summary:'Cola → ruta → ACK_SYNTHETIC; jamás se presenta como despacho real del 112.',targetAnchor:'#architecture',badge:'SYNTHETIC SIMULATION'},
   {num:'07',tag:'COMPARACIÓN',summary:'Lado a lado «Hoy (solo celular) vs Hipótesis Civic Relay» bajo las mismas condiciones.',targetAnchor:'#telecom-rf-radar-suite',badge:'SYNTHETIC SIMULATION'},
   {num:'08',tag:'EVIDENCIA Y PILOTO',summary:'Estado verificable del código, 0 relés físicos medidos aún y hoja de ruta para pilotos.',targetAnchor:'#evidence',badge:'PHYSICAL FIELD TEST PENDING'}
  ]
 },
 en:{
  brandTag:'CIVIC RELAY (PLATFORM) · OEP — OFFLINE EMERGENCY PROTOCOL (RESEARCH PROTOCOL)',
  title:'When the network goes down, coordination should not disappear.',
  subtitle:'Civic Relay is a European technology programme for risk anticipation, communication continuity and coordination of people, teams and infrastructure. It brings together sourced information, retained messages, authorized terrestrial or satellite routes and verifiable receipts. Today it demonstrates software and simulation; physical validation and institutional integrations remain pending.',
  exactQuote:'“Civic Relay researches how to coordinate alerts, voluntary human status check-ins, and alternative routes across participating devices and compatible networks when connectivity partially fails. The prototype lets you experiment with emergency zones, permissions, messages, store-and-forward queuing, and acknowledgments in a simulated scenario. Real phone-to-phone and official emergency service communication still requires validation and authorized integration.”',
  ctaSimulate:'Simulate an emergency',
  ctaExploreMap:'Explore interactive map',
  ctaEvidence:'See what works today',
  surfacesTitle:'THREE COMPLEMENTARY SURFACES (PROGRESSIVE DISCLOSURE)',
  surfaces:[
   {id:'surface-discover',tag:'A · DISCOVER',name:'30-Second Story & Primer',desc:'What problem it solves, for whom, and with what explicit boundaries—no 3GPP/CSI/CAP jargon required.',targetAnchor:'#what-oep-does',routeHref:'/'},
   {id:'surface-explore',tag:'B · EXPLORE / MISSION CONTROL',name:'3D Globe + Sector Intelligence CCTV',desc:'3D Globe with raycast object selection, sectors (El Tiemblo, Valencia, Arnhem), estimated FOV cones, and public/demo cameras.',targetAnchor:'#sector-intelligence',routeHref:'/mission-control/'},
   {id:'surface-science',tag:'C · INVESTIGATE / SCIENCE & LAB',name:'Deterministic Engine, Crypto & Evidence',desc:'Store-and-Forward queue, real WebCrypto ECDSA P-256 signatures, Android Nearby lab source, and scientific truth matrix.',targetAnchor:'#routing-lab',routeHref:'/science/'}
  ],
  eightScenes:[
   {num:'01',tag:'DISASTER',summary:'Wildfire or blackout disables a tower; sector coverage map updates immediately.',targetAnchor:'#story',badge:'SYNTHETIC SIMULATION'},
   {num:'02',tag:'PEOPLE',summary:'Participating nodes report SAFE or SOS; UNKNOWN means unconfirmed silence, never casualty.',targetAnchor:'#routing-lab',badge:'REAL CODE / LOCAL LAB'},
   {num:'03',tag:'CONSENT',summary:'Granular opt-in permissions; no remote phone sensor is ever turned on without OS/user consent.',targetAnchor:'#routing-lab',badge:'REAL CODE / LOCAL LAB'},
   {num:'04',tag:'ROUTES',summary:'Routing traffic-cop evaluates BLE/Wi-Fi/Gateway paths by battery, priority, and TTL.',targetAnchor:'#how-it-works',badge:'REAL CODE / LOCAL LAB'},
   {num:'05',tag:'SECTORS & CAMERAS',summary:'Drill down from Globe to Sector (El Tiemblo/Valencia/Arnhem) with public road metadata & FOV cones.',targetAnchor:'#sector-intelligence',badge:'LIVE THIRD-PARTY DATA — SOURCE/TIMESTAMP'},
   {num:'06',tag:'COORDINATION & ACK',summary:'Queue → decision → ACK_SYNTHETIC; never misrepresented as a live 112 dispatch.',targetAnchor:'#architecture',badge:'SYNTHETIC SIMULATION'},
   {num:'07',tag:'COMPARISON',summary:'Side-by-side “Conventional cellular-only vs Civic Relay hypothesis” under identical seed parameters.',targetAnchor:'#telecom-rf-radar-suite',badge:'SYNTHETIC SIMULATION'},
   {num:'08',tag:'EVIDENCE & PILOT',summary:'Verifiable code status, 0 measured physical field relays yet, and institutional pilot roadmap.',targetAnchor:'#evidence',badge:'PHYSICAL FIELD TEST PENDING'}
  ]
 },
 nl:{
  brandTag:'CIVIC RELAY (PLATFORM) · OEP — OFFLINE EMERGENCY PROTOCOL (ONDERZOEKSPROTOCOL)',
  title:'Als het netwerk uitvalt, mag de coördinatie niet verdwijnen.',
  subtitle:'Civic Relay is een Europees technologieprogramma voor risicoanticipatie, communicatiecontinuïteit en coördinatie van mensen, teams en infrastructuur. Het verbindt herleidbare informatie, bewaarde berichten, geautoriseerde aardse of satellietroutes en verifieerbare ontvangstbewijzen. Vandaag demonstreert het software en simulatie; fysieke validatie en institutionele integraties zijn nog nodig.',
  exactQuote:'“Civic Relay onderzoekt hoe meldingen, vrijwillige persoonsstatussen en alternatieve routes tussen deelnemende apparaten en compatibele netwerken gecoördineerd kunnen worden bij gedeeltelijke netwerkuitval. Het prototype laat u experimenteren met noodzones, toestemmingen, berichten, store-and-forward wachtrijen en ontvangstbevestigingen in een gesimuleerd scenario. Echte communicatie tussen telefoons en met hulpdiensten vereist nog validatie en geautoriseerde integratie.”',
  ctaSimulate:'Simuleer een noodgeval',
  ctaExploreMap:'Verken interactieve kaart',
  ctaEvidence:'Bekijk wat echt werkt',
  surfacesTitle:'DRIE COMPLEMENTAIRE OPPERVLAKKEN (PROGRESSIEVE ONTSLUITING)',
  surfaces:[
   {id:'surface-discover',tag:'A · ONTDEKKEN',name:'Verhaal & Overzicht in 30s',desc:'Welk probleem het oplost, voor wie en met welke eerlijke grenzen—zonder 3GPP/CSI/CAP-jargon.',targetAnchor:'#what-oep-does',routeHref:'/nl/'},
   {id:'surface-explore',tag:'B · VERKENNEN / MISSION CONTROL',name:'3D-Globe + Sector Intelligence CCTV',desc:'3D-globe met raycast-selectie, sectoren (El Tiemblo, Valencia, Arnhem), geschatte FOV-kegels en openbare/demo-camera’s.',targetAnchor:'#sector-intelligence',routeHref:'/nl/mission-control/'},
   {id:'surface-science',tag:'C · ONDERZOEKEN / SCIENCE & LAB',name:'Deterministische Engine, Crypto & Bewijs',desc:'Store-and-Forward wachtrij, echte WebCrypto ECDSA P-256-handtekeningen, Android Nearby-lab en wetenschappelijke matrix.',targetAnchor:'#routing-lab',routeHref:'/nl/science/'}
  ],
  eightScenes:[
   {num:'01',tag:'RAMP',summary:'Natuurbrand of stroomuitval schakelt een mast uit; sectordekking verandert direct.',targetAnchor:'#story',badge:'SYNTHETIC SIMULATION'},
   {num:'02',tag:'MENSEN',summary:'Deelnemende nodes melden SAFE of SOS; UNKNOWN betekent geen reactie, nooit bevestigd slachtoffer.',targetAnchor:'#routing-lab',badge:'REAL CODE / LOCAL LAB'},
   {num:'03',tag:'TOESTEMMING',summary:'Expliciete opt-in rechten; geen enkele sensor wordt op afstand zonder OS-toestemming geactiveerd.',targetAnchor:'#routing-lab',badge:'REAL CODE / LOCAL LAB'},
   {num:'04',tag:'ROUTES',summary:'Verkeersregelaar kiest tussen virtuele BLE/Wi-Fi/Gateway op basis van accu, prioriteit en TTL.',targetAnchor:'#how-it-works',badge:'REAL CODE / LOCAL LAB'},
   {num:'05',tag:'SECTOREN & CAMERA’S',summary:'Van wereldbol naar sector (El Tiemblo/Valencia/Arnhem) met openbare wegmetadata & FOV-kegels.',targetAnchor:'#sector-intelligence',badge:'LIVE THIRD-PARTY DATA — SOURCE/TIMESTAMP'},
   {num:'06',tag:'COÖRDINATIE & ACK',summary:'Wachtrij → beslissing → ACK_SYNTHETIC; nooit gepresenteerd als echte 112-inzet.',targetAnchor:'#architecture',badge:'SYNTHETIC SIMULATION'},
   {num:'07',tag:'VERGELIJKING',summary:'Zij-aan-zij “Alleen mobiel vs Civic Relay-hypothese” onder exact dezelfde voorwaarden.',targetAnchor:'#telecom-rf-radar-suite',badge:'SYNTHETIC SIMULATION'},
   {num:'08',tag:'BEWIJS & PILOT',summary:'Controleerbare codestatus, nog 0 fysieke veldrelays gemeten en roadmap voor pilots.',targetAnchor:'#evidence',badge:'PHYSICAL FIELD TEST PENDING'}
  ]
 }
};

export default function InvestorPage({locale}:{locale:Locale}){
 const t=getCopy(locale);
 const pitch=routingPitch[locale];
 const th=thirtySecondThesis[locale];
 return <main id="top" className="site-root">
  <LanguageDocument locale={locale}/>
  <div className="global-grid" aria-hidden="true"/>
  <ResponsiveHeader locale={locale}/>
  <AudienceFilter locale={locale}/>
  <div data-for="citizen coord eng inv"><SendaHome locale={locale}/></div>
  <div data-for="citizen coord eng inv"><section id="hero-30s" className="hero container">
   <div className="hero-copy">
    <div className="eyebrow"><span className="eyebrow-line"/>{t.hero.eyebrow}</div>
    <h1>{t.hero.first}<br/><span className="heading-muted">{t.hero.middle}</span><br/><span className="heading-urgent">{t.hero.last}</span></h1>
    <div className="hero-divider"><span>{t.hero.line}</span><span>↓</span></div>
    <div data-testid="thirty-second-thesis-card" className="apple-bento-thesis">
     <div className="apple-thesis-top">
      <small className="apple-thesis-kicker">{th.brandTag}</small>
      <div className="apple-loop-strip" aria-hidden="true">
       <span className="apple-loop-pill is-coral">01 · {locale==='es'?'OBSERVAR':locale==='nl'?'OBSERVEREN':'OBSERVE'}</span>
       <span className="apple-loop-arrow">→</span>
       <span className="apple-loop-pill is-ice">02 · {locale==='es'?'DECIDIR':locale==='nl'?'BESLISSEN':'DECIDE'}</span>
       <span className="apple-loop-arrow">→</span>
       <span className="apple-loop-pill is-emerald">03 · {locale==='es'?'COORDINAR':locale==='nl'?'COÖRDINEREN':'COORDINATE'}</span>
      </div>
     </div>
     <h2 className="apple-thesis-title">{th.title}</h2>
     <p className="apple-thesis-subtitle">{th.subtitle}</p>
     <blockquote className="apple-thesis-quote">
      {th.exactQuote}
     </blockquote>
    </div>
    <p className="hero-lede">{t.hero.desc} <strong>{pitch.promise}</strong></p>
    <div className="hero-actions" style={{display:'flex',flexWrap:'wrap',gap:'0.55rem'}}>
     <a className="button-primary" data-testid="hero-cta-simulate" href="#routing-lab">{th.ctaSimulate} <span>↘</span></a>
     <a className="button-outline" data-testid="hero-cta-explore-map" href="#sector-intelligence">{th.ctaExploreMap} <span>↘</span></a>
     <a className="button-outline" data-testid="hero-cta-evidence" href="#evidence">{th.ctaEvidence} <span>↘</span></a>
     <a className="button-outline" href="#hyperframes-cinema">{locale==='es'?'VER PELÍCULA KEYNOTE (5 ACTOS)':locale==='nl'?'BEKIJK KEYNOTE-FILM (5 AKTEN)':'WATCH KEYNOTE FILM (5 ACTS)'} <span>↘</span></a>
     <a className="button-outline" href="#telecom-rf-radar-suite">{t.hero.action} <span>↘</span></a>
     <a className="button-outline" href="#live-hardware-and-funding">{locale==='es'?'EJECUCIÓN REAL + INVERSIÓN':locale==='nl'?'LIVE NODE & FONDSEN':'LIVE NODE & FUNDING'} <span>↘</span></a>
    </div>
    <div className="proof-rail"><div><span className="proof-circle"/>{t.hero.proof}</div><div>{t.hero.gap}</div><div className="prototype-warning">{t.hero.note}</div></div>
   </div>
   <MissionControl locale={locale}/>
  </section></div>

  <div data-for="coord eng inv"><MasterVision locale={locale}/></div>
  {/* Three Complementary Surfaces Switcher (A: Discover / B: Explore Mission Control / C: Investigate Science) */}
  <div data-for="citizen coord inv"><section className="container apple-surfaces-section" aria-label={th.surfacesTitle} data-testid="three-surfaces-switcher">
   <div className="apple-bento-surfaces">
    <div className="apple-bento-surfaces-head">
     <p className="eyebrow" style={{margin:0,color:'#91d7e8'}}>{th.surfacesTitle}</p>
     <span className="apple-bento-tag">APPLE HIG · PROGRESSIVE DISCLOSURE</span>
    </div>
    <div className="apple-bento-surfaces-grid">
     {th.surfaces.map(s=>
      <article key={s.id} data-testid={s.id} className="apple-bento-surface-card">
       <div>
        <small className="apple-surface-kicker">{s.tag}</small>
        <h3 className="apple-surface-name">{s.name}</h3>
        <p className="apple-surface-desc">{s.desc}</p>
       </div>
       <div className="apple-surface-links">
        <a href={s.targetAnchor} className="apple-surface-anchor-link">{locale==='es'?'Ir a sección ↘':locale==='nl'?'Ga naar sectie ↘':'Jump to section ↘'}</a>
        <a href={s.routeHref} className="apple-surface-route-link">{locale==='es'?'Vista dedicada ↗':locale==='nl'?'Eigen weergave ↗':'Dedicated view ↗'}</a>
       </div>
      </article>
     )}
    </div>
   </div>
  </section></div>

  {/* 8-Scene Causal Journey Overview Strip (Section 4 of PROMPT_MASTER.md) */}
  <div data-for="citizen coord"><section className="container apple-scenes-section" aria-label="Eight-scene causal product journey" data-testid="eight-scene-journey-bar">
   <div className="apple-bento-scenes-grid">
    {th.eightScenes.map(sc=>
     <a key={sc.num} href={sc.targetAnchor} data-testid={`scene-card-${sc.num}`} className="apple-bento-scene-card">
      <div className="apple-scene-top">
       <strong className="apple-scene-num">{sc.num} — {sc.tag}</strong>
       <span className="apple-scene-arrow" aria-hidden="true">↘</span>
      </div>
      <p className="apple-scene-summary">{sc.summary}</p>
      <small className="apple-scene-badge">{sc.badge}</small>
     </a>
    )}
   </div>
  </section></div>

  <aside role="note" className="container apple-truth-note">
   <strong>{locale==='es'?'ESTADO REAL · PROTOTIPO DE INVESTIGACIÓN':locale==='nl'?'WERKELIJKE STATUS · ONDERZOEKSPROTOTYPE':'ACTUAL STATUS · RESEARCH PROTOTYPE'}</strong>
   <p>{locale==='es'?'La simulación de rutas, satélites, zonas y radar RF/CSI es sintética. WebCrypto ejecuta firmas reales en el navegador; WebRTC realiza un bucle local, no un enlace entre teléfonos. Android Nearby es un laboratorio sin ensayos físicos publicados. No hay detección validada de personas detrás de paredes, SOS operativo, conexión 112 ni transmisión satelital.':locale==='nl'?'Routes, satellieten, zones en RF/CSI-radar zijn gesimuleerd. WebCrypto gebruikt echte browserhandtekeningen, maar WebRTC is een lokale loopback, geen verbinding tussen telefoons. De Android Nearby-labapp heeft geen gepubliceerde fysieke veldproeven. Geen gevalideerde mensdetectie door muren, echte SOS-dienst, 112-koppeling of satellietuplink.':'Routing, satellite, zone and RF/CSI radar data are simulated. WebCrypto performs real browser signatures, but WebRTC is a same-page loopback, not phone-to-phone communication. Android Nearby is a laboratory app with no published physical field trials. No validated through-wall human sensing, operational SOS, 112 integration, or satellite uplink.'}</p>
  </aside>
  <div className="ribbon"><div className="container ribbon-inner"><span>OEP / INTEROPERABLE OFFLINE EMERGENCY COORDINATION</span><strong>{t.hero.line}</strong><span>2026 / OPEN SOURCE R&D</span></div></div>
  <nav className="oep-chapter-nav" aria-label={locale==='es'?'Recorrer el protocolo':locale==='nl'?'Verken het protocol':'Explore the protocol'}>
   <div className="container oep-chapter-nav-inner">
    {chapterNavigation[locale].map((item,i)=><a href={item.href} key={item.href}><span>{String(i+1).padStart(2,'0')}</span>{item.label}</a>)}
   </div>
  </nav>
  <div className="container">
   <div data-for="citizen inv"><HyperFramesCinemaDeck locale={locale}/></div>
  </div>
  <div data-for="citizen coord"><WhatItDoes locale={locale}/></div>
  <div data-for="coord eng"><SectorIntelligenceConsole locale={locale}/></div>
  <div data-for="eng"><TelecomAndRfRadarSuite locale={locale}/></div>
  <div data-for="eng inv"><LiveHardwareAndDealRoomConsole locale={locale}/></div>
  <div data-for="citizen coord"><CrisisStory locale={locale}/></div>
  <div data-for="citizen"><ScrollExperience locale={locale}/></div>
  <div data-for="coord eng"><SystemExplained locale={locale}/></div>
  <div data-for="coord eng"><CoordinationLab locale={locale}/></div>
  <div data-for="eng"><DeveloperBlueprint locale={locale}/></div>
  <div data-for="eng inv"><EvidenceBoard locale={locale}/></div>
  <div data-for="citizen coord eng inv"><section id="solution" className="product-section container">
   <div className="product-title-block">
    <div><p className="eyebrow">{t.solution.eyebrow}</p><h2>{pitch.title}</h2><p className="product-subhead">{pitch.lead}</p></div>
    <p className="product-explainer">{pitch.why}</p>
   </div>
   <div className="three-step-bar"><span>{t.solution.howEyebrow}</span><span>01 — 02 — 03</span></div>
   <div className="pipeline-grid">{t.solution.how.map((item,i)=><article className="pipeline-item" key={item.title}><span className="pipe-count">0{i+1}</span><div className="pipe-glyph">{i===0?'▣':i===1?'◫':'◎'}</div><h3>{item.title}</h3><p>{item.body}</p></article>)}</div>
   <div className="product-claim"><span className="product-claim-icon">!</span><span>{t.solution.limits}</span></div>
   <div className="audience-head">{t.solution.forTitle}</div>
   <div className="audience-grid">{t.solution.audiences.map(item=><article className="audience-card" key={item.tag}><span>{item.tag}</span><h3>{item.title}</h3><p>{item.body}</p></article>)}</div>
  </section></div>
  <div data-for="inv"><section id="investment" className="invest-section"><div className="container">
   <div className="section-heading invest-head"><div><p className="eyebrow">{t.invest.eyebrow}</p><h2>{t.invest.title}</h2></div><p>{pitch.invest}</p></div>
   <div className="invest-cards">{t.invest.cards.map(item=><article key={item.index} className="invest-card"><div className="invest-index"><span>{item.index} / 03</span><span>↗</span></div><h3>{item.title}</h3><p>{item.body}</p></article>)}</div>
   <div className="capital-grid"><article className="capital-model"><span>OPEN SOURCE / SERVICE-LED</span><h3>{t.invest.modelTitle}</h3><p>{t.invest.model}</p></article><article className="capital-request"><span>VALIDATED MILESTONES / NEXT FUNDING</span><h3>{t.invest.valueTitle}</h3><ol>{t.invest.value.map((item,i)=><li key={item}><b>0{i+1}</b><span>{item}</span></li>)}</ol></article></div>
   <p className="invest-validation"><strong>EVIDENCE FIRST — </strong>{t.invest.validation}</p>
  </div></section></div>
  <div data-for="inv coord"><section id="roadmap" className="roadmap-band"><div className="container roadmap-inner">
   <div className="roadmap-intro"><p className="eyebrow">{t.roadmap.eyebrow}</p><h2>{t.roadmap.title}</h2><p>{t.roadmap.lead}</p><a className="text-cta" href={dossier} target="_blank" rel="noopener noreferrer">{t.roadmap.link} ↗</a></div>
   <div className="roadmap-steps">{t.roadmap.steps.map((item,i)=><article className="roadmap-step" key={item.stage}><span className="step-number">0{i+1}</span><div><div className="step-top"><span>{item.stage}</span><b className={i===0?'status-demonstrated':''}>{item.status}</b></div><h3>{item.title}</h3><p>{item.body}</p></div></article>)}</div>
  </div></section></div>
  <div data-for="inv coord"><section className="closing container" id="partner">
   <div><p className="eyebrow">{t.closing.eyebrow}</p><h2>{t.closing.title}</h2><p>{pitch.closing}</p>
    <div className="funding-line"><span>{t.closing.fundingTitle}</span><strong>{t.closing.call}</strong><small>{t.closing.deadline}</small><small>{t.closing.noGuarantee}</small></div>
   </div>
   <div className="closing-actions"><a className="button-primary" href={contact} target="_blank" rel="noopener noreferrer">{t.closing.contact} <span>↗</span></a><a className="button-outline" href={funding} target="_blank" rel="noopener noreferrer">{t.closing.funding} <span>↗</span></a><a className="text-cta" href={source} target="_blank" rel="noopener noreferrer">{t.closing.source} ↗</a></div>
  </section></div>
  <footer className="footer"><div className="container footer-inner"><span className="footer-brand">Civic Relay · OEP — Offline Emergency Protocol <small>© 2026</small></span><span>{t.footer}</span><a href="#top">↑ TOP</a></div></footer>
  <AppleLivingNav locale={locale}/>
 </main>;
}
