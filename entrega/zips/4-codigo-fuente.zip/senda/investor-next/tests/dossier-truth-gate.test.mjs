import {test} from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,readFileSync,readdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import * as oepCore from '../lib/index.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'../..');
const read=(rel)=>readFileSync(resolve(root,rel),'utf8');

test('dossier and security docs contain zero fabricated class names, wrong versions or closed-fund claims',()=>{
  const dirs=['docs/investor','docs/security','docs/audits'];
  const banned=[
    'SessionCancellationGuard',
    'TrialExportFormatter',
    'NearbyLabProtocolTest',
    'android-nearby-lab.yml',
    'oep-evidence-run.test.mjs',
    'P2P_CLUSTER',
    'play-services-nearby:19.3.0',
    'oep-android-nearby-experimental-debug-apk'
  ];
  for(const dir of dirs){
    for(const file of readdirSync(resolve(root,dir)).filter(f=>f.endsWith('.md'))){
      const rel=`${dir}/${file}`;
      if(file==='KARPATHY_6_AGENT_AUDIT_2026.md')continue;
      const content=read(rel);
      for(const token of banned){
        assert.ok(!content.includes(token),`${rel} still contains fabricated/stale token: ${token}`);
      }
    }
  }
});

test('DEPENDENCY_AND_LICENSE_AUDIT.md matches actual investor-next/package.json and Android build.gradle.kts',()=>{
  const audit=read('docs/security/DEPENDENCY_AND_LICENSE_AUDIT.md');
  const pkg=JSON.parse(read('investor-next/package.json'));
  const gradle=read('experimental/android-nearby/app/build.gradle.kts');
  assert.ok(audit.includes(`| \`next\` | \`${pkg.dependencies.next}\``),'next version mismatch in audit');
  assert.ok(audit.includes(`| \`react\` | \`${pkg.dependencies.react}\``),'react version mismatch in audit');
  assert.ok(audit.includes(`| \`three\` | \`${pkg.dependencies.three}\``),'three version mismatch in audit');
  assert.ok(gradle.includes('play-services-nearby:19.5.1'),'gradle nearby version changed');
  assert.ok(audit.includes('19.5.1'),'audit missing real play-services-nearby 19.5.1 version');
});

test('all Android Java classes including ECDSA LabReceiptSigner and LabPersistentQueue exist on disk',()=>{
  for(const cls of ['MainActivity','LabDeliveryGuard','LabDeadlinePolicy','LabTrialJournal','LabReceiptSigner','LabPersistentQueue']){
    assert.equal(
      existsSync(resolve(root,`experimental/android-nearby/app/src/main/java/eu/civicrelay/nearbylab/${cls}.java`)),
      true,
      `Missing Android main class ${cls}.java`
    );
  }
  for(const testCls of ['LabDeliveryGuardTest','LabDeadlinePolicyTest','LabTrialJournalTest','LabReceiptSignerTest','LabPersistentQueueTest']){
    assert.equal(
      existsSync(resolve(root,`experimental/android-nearby/app/src/test/java/eu/civicrelay/nearbylab/${testCls}.java`)),
      true,
      `Missing Android test class ${testCls}.java`
    );
  }
});

test('unified OEP protocol entrypoint exports routing, store-forward, and policy engines',()=>{
  assert.equal(typeof oepCore.runScenario,'function');
  assert.equal(typeof oepCore.createStoreForwardEngine,'function');
  assert.equal(typeof oepCore.createInMemoryAdapter,'function');
  assert.equal(typeof oepCore.capabilityState,'function');
  assert.equal(typeof oepCore.recordSafetyResponse,'function');
  assert.equal(typeof oepCore.revokeSafetyRecord,'function');
  assert.equal(typeof oepCore.expireSafetyRecord,'function');
  assert.equal(typeof oepCore.energyPolicy,'function');
  assert.equal(typeof oepCore.acceptAuthorizedCapAlert,'function');
  assert.equal(existsSync(resolve(root,'docs/README.md')),true);
  assert.equal(existsSync(resolve(root,'.github/ISSUE_TEMPLATE/pilot-or-grant-partner.yml')),true);
});


test('browser lab never fabricates FFT sensor readings or cross-tab RTT',()=>{
  const source=read('investor-next/app/live-hardware-console.tsx');
  assert.ok(source.includes('setMicError(true)'), 'mic permission error must be visible');
  assert.ok(source.includes('setFftBins(Array.from({ length: 32 }, () => 0))'), 'permission denied must be fail-closed');
  assert.ok(!source.includes('Fallback oscillator FFT in case microphone permission is denied'), 'fabricated FFT fallback returned');
  assert.ok(!source.includes('Math.max(0.4, Date.now() - incoming.timestampMs)'), 'fake cross-tab RTT returned');
  assert.ok(source.includes('BROADCAST_CHANNEL_SAME_ORIGIN_CONTEXT_ONLY'), 'cross-tab transport must not be called phone P2P');
  assert.ok(source.includes('WebRTC same-page loopback RTT (lab only)'), 'loopback must not be sold as phone P2P');
});

test('funding copy respects NLnet GenAI v2.0 and does not assert unverified grant eligibility',()=>{
  const source=read('investor-next/app/live-hardware-console.tsx');
  assert.ok(source.includes("target.id === 'F01-NLNET' ? ''"), 'NLnet proposal generation should stay disabled');
  assert.ok(source.includes('https://nlnet.nl/propose/'), 'official NLnet call link absent');
  assert.ok(source.includes('3 November 2026, 12:00 CET'), 'verified NLnet deadline absent');
  assert.ok(source.includes('5 November 2026 (official call)'), 'verified Horizon deadline absent');
  assert.ok(source.includes('ELIGIBILITY UNVERIFIED'), 'grant programme exploratory gates absent');
  assert.ok(!source.includes('Apache-2.0 Repository:'), 'MIT/Apache false assertion returned');
  assert.ok(!source.includes('Verified live prototype & code facts:'), 'unsubstantiated funding claims returned');
});

test('RF and satellite UI labels remain explicitly synthetic across three languages',()=>{
  const source=read('investor-next/app/telecom-rf-radar-suite.tsx');
  assert.ok(source.includes('CÁMARA ACTIVA · MAPA RF SINTÉTICO (NO MEDICIÓN)'));
  assert.ok(source.includes('CAMERA ACTIVE · SYNTHETIC RF OVERLAY (NOT MEASURED)'));
  assert.ok(source.includes('CAMERA ACTIEF · GESIMULEERDE RF-OVERLAY (GEEN METING)'));
  assert.ok(source.includes('SYNTHETIC TARGETS: ${radarResult.detectedCount}/3'));
  assert.ok(!source.includes('DETECTED BEHIND WALL: ${radarResult.detectedCount}/3'));
});
