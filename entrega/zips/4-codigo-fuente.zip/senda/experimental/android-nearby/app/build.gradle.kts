plugins { id("com.android.application") }
android {
    namespace = "eu.civicrelay.nearbylab"
    compileSdk = 35
    defaultConfig {
        applicationId = "eu.civicrelay.nearbylab"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-experimental"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    implementation("com.google.android.gms:play-services-nearby:19.5.1")
}
